# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import HtmlResponse
from jobparser.items import JobparserItem
from scrapy.loader import ItemLoader

class SjruSpider(scrapy.Spider):
    name = 'sjru'
    allowed_domains = ['superjob.ru']
    start_urls = ['https://www.superjob.ru/vacancy/search/?keywords=Дворник']

    def parse(self, response: HtmlResponse):
        next_page = response.xpath('//a[@class="icMQ_ _1_Cht _3ze9n f-test-button-dalshe f-test-link-dalshe"]/@href').get()
        yield response.follow(next_page, callback=self.parse)
        vacancy = response.xpath(
            '//div[contains(@class, "f-test-vacancy-item")]//a[contains(@class, "icMQ_") and contains(@class,"_1QIBo ")]/@href' ).getall()
        for link in vacancy:
            yield response.follow( link, self.vacancy_parse )

    def vacancy_parse(self, response: HtmlResponse):
        loader = ItemLoader(item=JobparserItem(), response=response )
        loader.add_xpath( 'name', '//div[contains(@class, "_3zucV")]//h1[contains(@class, "_3mfro")]/text()' )
        loader.add_xpath( 'salary', '//span[contains(@class, "_3mfro") and contains(@class,"_2Wp8I") and contains(@class,"ZON4b")]/*' )
        loader.add_xpath( 'description', '//span[contains(@class, "_3mfro") and contains(@class,"_2LeqZ") and contains(@class,"_1hP6a")]/span/text()' )
        yield loader.load_item()