# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import HtmlResponse
from jobparser.items import JobparserItem
from scrapy.loader import ItemLoader

class HhruSpider(scrapy.Spider):
    name = 'hhru'
    allowed_domains = ['hh.ru']
    start_urls = ['https://hh.ru/search/vacancy?only_with_salary=false&clusters=true&area=2&enable_snippets=true&salary=&st=searchVacancy&text=дворник']

    def parse(self, response: HtmlResponse):
        next_page = response.css('a.HH-Pager-Controls-Next::attr(href)').get()
        yield response.follow(next_page, callback=self.parse)
        vacancy = response.css(
            'div.vacancy-serp-item__row_header a.HH-LinkModifier::attr(href)').getall()
        for link in vacancy:
            yield response.follow(link, self.vacancy_parse)

    def vacancy_parse(self, response: HtmlResponse):
        loader = ItemLoader(item=JobparserItem(), response=response )
        loader.add_css( 'name',
                          'div.vacancy-title h1.header span.highlighted::text' )
        loader.add_css( 'salary', 'div.vacancy-title p.vacancy-salary::text' )
        loader.add_css( 'description', 'div.g-user-content p *::text' )
        yield loader.load_item()
